import React from 'react';
import { View, ActivityIndicator, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';

import { RootStackParamList } from './src/types';
import { useAuth } from './src/hooks/useAuth';

import SplashScreen      from './src/screens/SplashScreen';
import LoginScreen       from './src/screens/LoginScreen';
import ClientDashboard   from './src/screens/ClientDashboard';
import ProviderDashboard from './src/screens/ProviderDashboard';
import AdminDashboard    from './src/screens/AdminDashboard';
import BookServiceScreen from './src/screens/BookServiceScreen';

const Stack = createStackNavigator<RootStackParamList>();

export default function App() {
  const { state, user } = useAuth();

  if (state === 'loading') {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#22D3EE" />
      </View>
    );
  }

  const getInitialRoute = (): keyof RootStackParamList => {
    if (state === 'unauthenticated') return 'Login';
    if (user?.role === 'provider') return 'ProviderDashboard';
    if (user?.role === 'admin') return 'AdminDashboard';
    return 'ClientDashboard';
  };

  return (
    <NavigationContainer>
      <StatusBar style="light" backgroundColor="#0A4F6E" />
      <Stack.Navigator
        initialRouteName={state === 'unauthenticated' ? 'Splash' : getInitialRoute()}
        screenOptions={{
          headerShown: false,
          cardStyle: { backgroundColor: '#F8FAFC' },
        }}
      >
        <Stack.Screen name="Splash"            component={SplashScreen} />
        <Stack.Screen name="Login"             component={LoginScreen} />
        <Stack.Screen name="ClientDashboard"   component={ClientDashboard} />
        <Stack.Screen name="ProviderDashboard" component={ProviderDashboard} />
        <Stack.Screen name="AdminDashboard"    component={AdminDashboard} />
        <Stack.Screen name="BookService"       component={BookServiceScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  loading: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0A4F6E',
  },
});
