// app.config.js  – replaces app.json for dynamic config
// Run: cp .env.example .env and fill in your real values
import 'dotenv/config';

export default {
  expo: {
    name: 'Cleanwave',
    slug: 'cleanwave',
    version: '1.0.0',
    orientation: 'portrait',
    icon: './assets/icon.png',
    userInterfaceStyle: 'light',
    scheme: 'cleanwave',
    newArchEnabled: true,
    splash: {
      image: './assets/splash-icon.png',
      resizeMode: 'contain',
      backgroundColor: '#0A4F6E',
    },
    ios: { supportsTablet: true },
    android: {
      adaptiveIcon: {
        foregroundImage: './assets/adaptive-icon.png',
        backgroundColor: '#0A4F6E',
      },
      edgeToEdgeEnabled: true,
      predictiveBackGestureEnabled: false,
    },
    web: { favicon: './assets/favicon.png' },
    plugins: ['expo-web-browser'],
    extra: {
      // Firebase
      firebaseApiKey:            process.env.FIREBASE_API_KEY,
      firebaseAuthDomain:        process.env.FIREBASE_AUTH_DOMAIN,
      firebaseProjectId:         process.env.FIREBASE_PROJECT_ID,
      firebaseStorageBucket:     process.env.FIREBASE_STORAGE_BUCKET,
      firebaseMessagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
      firebaseAppId:             process.env.FIREBASE_APP_ID,
      // Google OAuth
      googleWebClientId:         process.env.GOOGLE_WEB_CLIENT_ID,
      googleAndroidClientId:     process.env.GOOGLE_ANDROID_CLIENT_ID,
      googleIosClientId:         process.env.GOOGLE_IOS_CLIENT_ID,
    },
  },
};
