export type UserRole = 'client' | 'provider' | 'admin';

export interface AppUser {
  uid: string;
  email: string | null;
  firstName: string;
  role: UserRole;
}

export type JobStatus =
  | 'pending'
  | 'available'
  | 'accepted'
  | 'in_progress'
  | 'completed';

export interface Job {
  id: string;
  clientId: string;
  clientName: string;
  providerId?: string;
  location: string;
  area: number;
  date: string;
  status: JobStatus;
  payment?: number;
  rating?: number;
  notes?: string;
  createdAt: number;
}

export type RootStackParamList = {
  Splash: undefined;
  Login: undefined;
  ClientDashboard: undefined;
  ProviderDashboard: undefined;
  AdminDashboard: undefined;
  BookService: undefined;
};
