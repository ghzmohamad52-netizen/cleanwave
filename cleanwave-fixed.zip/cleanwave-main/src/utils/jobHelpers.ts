import { JobStatus } from '../types';

export const getStatusText = (status: JobStatus | string): string => {
  switch (status) {
    case 'pending':     return 'Pending';
    case 'available':   return 'Available';
    case 'in_progress': return 'In Progress';
    case 'accepted':    return 'Accepted';
    case 'completed':   return 'Completed';
    default:            return 'Unknown';
  }
};

export const getStatusColor = (status: JobStatus | string): string => {
  switch (status) {
    case 'pending':
    case 'available':   return '#10B981';
    case 'in_progress':
    case 'accepted':    return '#22D3EE';
    case 'completed':   return '#6B7280';
    default:            return '#6B7280';
  }
};

export const formatMAD = (value?: number): string =>
  value != null ? `MAD ${value.toLocaleString()}` : 'MAD 0';
