import { useState, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth } from '../config/firebase';
import { AppUser } from '../types';

type AuthState = 'loading' | 'authenticated' | 'unauthenticated';

export function useAuth() {
  const [state, setState]   = useState<AuthState>('loading');
  const [user, setUser]     = useState<AppUser | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Restore role + firstName from AsyncStorage (Firebase doesn't store custom fields)
        const stored = await AsyncStorage.getItem('user');
        if (stored) {
          const parsed: AppUser = JSON.parse(stored);
          setUser(parsed);
          setState('authenticated');
        } else {
          // Signed in via Firebase but no local data — force re-login
          setState('unauthenticated');
        }
      } else {
        setUser(null);
        setState('unauthenticated');
      }
    });

    return unsubscribe;
  }, []);

  return { state, user };
}
