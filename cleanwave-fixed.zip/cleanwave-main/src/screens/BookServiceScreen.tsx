import React, { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, ScrollView,
  TouchableOpacity, Alert, ActivityIndicator,
} from 'react-native';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';

import { db } from '../config/firebase';
import { AppUser, RootStackParamList } from '../types';
import { formatMAD } from '../utils/jobHelpers';

type Props = {
  navigation: StackNavigationProp<RootStackParamList, 'BookService'>;
};

const PRICE_PER_SQM = 15; // MAD per m²

const BookServiceScreen: React.FC<Props> = ({ navigation }) => {
  const [location, setLocation] = useState('');
  const [area, setArea]         = useState('');
  const [date, setDate]         = useState('');
  const [notes, setNotes]       = useState('');
  const [loading, setLoading]   = useState(false);

  const estimatedPayment = area ? Math.round(parseFloat(area) * PRICE_PER_SQM) : 0;

  const validate = (): string | null => {
    if (!location.trim()) return 'يرجى إدخال الموقع';
    const areaNum = parseFloat(area);
    if (!area || isNaN(areaNum) || areaNum <= 0) return 'يرجى إدخال مساحة صحيحة';
    if (!date.trim()) return 'يرجى إدخال التاريخ';
    return null;
  };

  const handleSubmit = async () => {
    const error = validate();
    if (error) {
      Alert.alert('خطأ', error);
      return;
    }

    setLoading(true);
    try {
      const stored = await AsyncStorage.getItem('user');
      if (!stored) {
        Alert.alert('خطأ', 'يرجى تسجيل الدخول أولاً');
        return;
      }
      const user: AppUser = JSON.parse(stored);

      await addDoc(collection(db, 'jobs'), {
        clientId:   user.uid,
        clientName: user.firstName,
        location:   location.trim(),
        area:       parseFloat(area),
        date:       date.trim(),
        notes:      notes.trim(),
        payment:    estimatedPayment,
        status:     'available',
        createdAt:  serverTimestamp(),
      });

      Alert.alert('تم الحجز ✅', 'سيتواصل معك مقدم الخدمة قريباً', [
        { text: 'حسناً', onPress: () => navigation.goBack() },
      ]);
    } catch {
      Alert.alert('خطأ', 'فشل في إرسال الطلب. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <Text style={styles.backText}>← رجوع</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>حجز خدمة تنظيف</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.form}>
          <Text style={styles.sectionTitle}>تفاصيل الموقع</Text>

          <Text style={styles.label}>الموقع / اسم الشاطئ *</Text>
          <TextInput
            style={styles.input}
            placeholder="مثال: شاطئ أكادير، المغرب"
            value={location}
            onChangeText={setLocation}
            placeholderTextColor="#9CA3AF"
          />

          <Text style={styles.label}>المساحة (m²) *</Text>
          <TextInput
            style={styles.input}
            placeholder="مثال: 500"
            value={area}
            onChangeText={setArea}
            keyboardType="numeric"
            placeholderTextColor="#9CA3AF"
          />

          <Text style={styles.label}>التاريخ المطلوب *</Text>
          <TextInput
            style={styles.input}
            placeholder="مثال: 2025-06-15"
            value={date}
            onChangeText={setDate}
            placeholderTextColor="#9CA3AF"
          />

          <Text style={styles.label}>ملاحظات إضافية</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="أي تفاصيل إضافية..."
            value={notes}
            onChangeText={setNotes}
            multiline
            numberOfLines={4}
            placeholderTextColor="#9CA3AF"
            textAlignVertical="top"
          />

          {/* Price estimate */}
          {estimatedPayment > 0 && (
            <View style={styles.estimateCard}>
              <Text style={styles.estimateLabel}>التكلفة التقديرية</Text>
              <Text style={styles.estimateValue}>{formatMAD(estimatedPayment)}</Text>
              <Text style={styles.estimateNote}>
                ({PRICE_PER_SQM} MAD × {area} m²)
              </Text>
            </View>
          )}

          <TouchableOpacity
            style={[styles.submitButton, loading && styles.buttonDisabled]}
            onPress={handleSubmit}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color="#0F172A" />
              : <Text style={styles.submitButtonText}>🌊  تأكيد الحجز</Text>
            }
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: '#F8FAFC' },
  header:          { backgroundColor: '#0A4F6E', paddingTop: 56, paddingBottom: 20, paddingHorizontal: 20 },
  backButton:      { marginBottom: 8 },
  backText:        { color: 'rgba(255,255,255,0.8)', fontSize: 14 },
  headerTitle:     { fontSize: 22, fontWeight: 'bold', color: '#FFFFFF' },
  scrollContent:   { padding: 20, paddingBottom: 40 },
  form:            { },
  sectionTitle:    { fontSize: 17, fontWeight: '700', color: '#0F172A', marginBottom: 16 },
  label:           { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 6 },
  input:           { backgroundColor: '#FFFFFF', borderRadius: 12, padding: 14, marginBottom: 16, borderWidth: 1, borderColor: '#E5E7EB', fontSize: 15, color: '#0F172A' },
  textArea:        { minHeight: 100 },
  estimateCard:    { backgroundColor: '#E0F2FE', borderRadius: 14, padding: 18, marginBottom: 20, alignItems: 'center' },
  estimateLabel:   { color: '#0A4F6E', fontSize: 14, marginBottom: 4 },
  estimateValue:   { color: '#0A4F6E', fontSize: 28, fontWeight: 'bold' },
  estimateNote:    { color: '#0A4F6E', opacity: 0.7, fontSize: 12, marginTop: 4 },
  submitButton:    { backgroundColor: '#22D3EE', padding: 18, borderRadius: 16, alignItems: 'center' },
  submitButtonText:{ color: '#0F172A', fontWeight: 'bold', fontSize: 16 },
  buttonDisabled:  { opacity: 0.55 },
});

export default BookServiceScreen;
