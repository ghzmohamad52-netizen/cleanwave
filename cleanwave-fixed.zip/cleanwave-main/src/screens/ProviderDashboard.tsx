import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, RefreshControl,
} from 'react-native';
import {
  collection, onSnapshot, query, where, orderBy,
  doc, updateDoc, serverTimestamp,
} from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';

import { db, auth } from '../config/firebase';
import { AppUser, Job, RootStackParamList } from '../types';
import { getStatusText, getStatusColor, formatMAD } from '../utils/jobHelpers';

type Props = {
  navigation: StackNavigationProp<RootStackParamList, 'ProviderDashboard'>;
};

type Tab = 'Available' | 'My Jobs' | 'Profile';

const TABS: { key: Tab; label: string; icon: string }[] = [
  { key: 'Available', label: 'Available', icon: '🌊' },
  { key: 'My Jobs',   label: 'My Jobs',   icon: '🗂️' },
  { key: 'Profile',   label: 'Profile',   icon: '👤' },
];

const ProviderDashboard: React.FC<Props> = ({ navigation }) => {
  const [availableJobs, setAvailableJobs] = useState<Job[]>([]);
  const [myJobs, setMyJobs]               = useState<Job[]>([]);
  const [user, setUser]                   = useState<AppUser | null>(null);
  const [activeTab, setActiveTab]         = useState<Tab>('Available');
  const [refreshing, setRefreshing]       = useState(false);
  const [accepting, setAccepting]         = useState<string | null>(null);

  useEffect(() => {
    AsyncStorage.getItem('user').then((stored) => {
      if (stored) setUser(JSON.parse(stored));
    });
  }, []);

  // Subscribe to available (unclaimed) jobs
  useEffect(() => {
    const q = query(
      collection(db, 'jobs'),
      where('status', '==', 'available'),
      orderBy('createdAt', 'desc'),
    );
    return onSnapshot(q, (snap) => {
      setAvailableJobs(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Job, 'id'>) })));
    });
  }, []);

  // Subscribe to this provider's accepted/in-progress/completed jobs
  useEffect(() => {
    if (!user?.uid) return;
    const q = query(
      collection(db, 'jobs'),
      where('providerId', '==', user.uid),
      orderBy('createdAt', 'desc'),
    );
    return onSnapshot(q, (snap) => {
      setMyJobs(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Job, 'id'>) })));
    });
  }, [user?.uid]);

  const handleLogout = () => {
    Alert.alert('تأكيد', 'هل تريد تسجيل الخروج؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'تسجيل الخروج',
        style: 'destructive',
        onPress: async () => {
          try {
            await signOut(auth);
            await AsyncStorage.multiRemove(['token', 'user']);
            navigation.replace('Login');
          } catch {
            Alert.alert('خطأ', 'فشل في تسجيل الخروج');
          }
        },
      },
    ]);
  };

  const handleAcceptJob = async (jobId: string) => {
    if (!user?.uid) return;
    if (accepting) return; // prevent double-tap

    Alert.alert('قبول الطلب', 'هل تريد قبول هذه المهمة؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'قبول',
        onPress: async () => {
          setAccepting(jobId);
          try {
            await updateDoc(doc(db, 'jobs', jobId), {
              status:     'accepted',
              providerId: user.uid,
              acceptedAt: serverTimestamp(),
            });
            Alert.alert('نجاح ✅', 'تم قبول الطلب');
          } catch {
            Alert.alert('خطأ', 'فشل في قبول الطلب. ربما تم قبوله من شخص آخر.');
          } finally {
            setAccepting(null);
          }
        },
      },
    ]);
  };

  const handleCompleteJob = async (jobId: string) => {
    Alert.alert('إتمام المهمة', 'هل أتممت هذه المهمة؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'نعم، أتممتها',
        onPress: async () => {
          try {
            await updateDoc(doc(db, 'jobs', jobId), {
              status:      'completed',
              completedAt: serverTimestamp(),
            });
          } catch {
            Alert.alert('خطأ', 'فشل في تحديث الحالة');
          }
        },
      },
    ]);
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 800);
  }, []);

  const completedJobs  = myJobs.filter((j) => j.status === 'completed');
  const totalEarnings  = completedJobs.reduce((s, j) => s + (j.payment ?? 0), 0);

  /* ── Render helpers ─────────────────────────────────────────────────── */

  const renderHeader = () => (
    <View style={styles.header}>
      <View style={styles.headerTop}>
        <View>
          <Text style={styles.welcome}>مرحباً،</Text>
          <Text style={styles.userName}>{user?.firstName || 'مقدم الخدمة'}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
        </View>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutText}>خروج</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.earningsBanner}>
        <Text style={styles.earningsLabel}>إجمالي الأرباح</Text>
        <Text style={styles.earningsValue}>{formatMAD(totalEarnings)}</Text>
      </View>
    </View>
  );

  const renderAvailableJobCard = (job: Job) => (
    <View key={job.id} style={styles.jobCard}>
      <View style={styles.jobHeader}>
        <Text style={styles.jobClient}>{job.clientName || 'Client'}</Text>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status) }]}>
          <Text style={styles.statusText}>{getStatusText(job.status)}</Text>
        </View>
      </View>
      <Text style={styles.jobDetails}>
        📍 {job.location}  ·  📐 {job.area} m²  ·  📅 {job.date}
      </Text>
      <Text style={styles.jobPayment}>{formatMAD(job.payment)}</Text>
      {job.notes ? <Text style={styles.jobNotes}>📝 {job.notes}</Text> : null}
      <TouchableOpacity
        style={[styles.acceptButton, accepting === job.id && styles.buttonDisabled]}
        onPress={() => handleAcceptJob(job.id)}
        disabled={!!accepting}
      >
        <Text style={styles.acceptButtonText}>
          {accepting === job.id ? 'جاري القبول...' : 'قبول المهمة'}
        </Text>
      </TouchableOpacity>
    </View>
  );

  const renderMyJobCard = (job: Job) => (
    <View key={job.id} style={styles.jobCard}>
      <View style={styles.jobHeader}>
        <Text style={styles.jobClient}>{job.clientName || 'Client'}</Text>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status) }]}>
          <Text style={styles.statusText}>{getStatusText(job.status)}</Text>
        </View>
      </View>
      <Text style={styles.jobDetails}>
        📍 {job.location}  ·  📐 {job.area} m²  ·  📅 {job.date}
      </Text>
      <Text style={styles.jobPayment}>{formatMAD(job.payment)}</Text>
      {job.status !== 'completed' && (
        <TouchableOpacity
          style={styles.completeButton}
          onPress={() => handleCompleteJob(job.id)}
        >
          <Text style={styles.completeButtonText}>✅  Mark as Complete</Text>
        </TouchableOpacity>
      )}
      {job.status === 'completed' && job.rating && (
        <Text style={styles.ratingText}>⭐ Rating: {job.rating}/5</Text>
      )}
    </View>
  );

  const renderAvailable = () => (
    <View style={styles.section}>
      <View style={styles.statsRow}>
        {[
          { label: 'Available', value: String(availableJobs.length) },
          { label: 'My Jobs',   value: String(myJobs.length) },
          { label: 'Completed', value: String(completedJobs.length) },
        ].map((s) => (
          <View key={s.label} style={styles.statCard}>
            <Text style={styles.statNumber}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>
      <Text style={styles.sectionTitle}>Available Jobs ({availableJobs.length})</Text>
      {availableJobs.length === 0
        ? <Text style={styles.emptyText}>لا توجد مهام متاحة الآن</Text>
        : availableJobs.map(renderAvailableJobCard)
      }
    </View>
  );

  const renderMyJobs = () => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Active ({myJobs.filter(j => j.status !== 'completed').length})</Text>
      {myJobs.filter(j => j.status !== 'completed').length === 0
        ? <Text style={styles.emptyText}>لا توجد مهام نشطة</Text>
        : myJobs.filter(j => j.status !== 'completed').map(renderMyJobCard)
      }
      <Text style={[styles.sectionTitle, { marginTop: 20 }]}>
        Completed ({completedJobs.length})
      </Text>
      {completedJobs.length === 0
        ? <Text style={styles.emptyText}>لا توجد مهام مكتملة</Text>
        : completedJobs.map(renderMyJobCard)
      }
    </View>
  );

  const renderProfile = () => (
    <View style={styles.section}>
      <View style={styles.profileCard}>
        <Text style={styles.profileAvatar}>🧹</Text>
        <Text style={styles.profileName}>{user?.firstName}</Text>
        <Text style={styles.profileEmail}>{user?.email}</Text>
        <View style={styles.profileBadge}>
          <Text style={styles.profileBadgeText}>Service Provider</Text>
        </View>
      </View>
      <View style={styles.statsRow}>
        {[
          { label: 'Total Jobs',  value: String(myJobs.length) },
          { label: 'Completed',   value: String(completedJobs.length) },
          { label: 'Earnings',    value: `MAD ${totalEarnings}` },
        ].map((s) => (
          <View key={s.label} style={styles.statCard}>
            <Text style={[styles.statNumber, { fontSize: s.label === 'Earnings' ? 14 : 20 }]}>
              {s.value}
            </Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>
      <TouchableOpacity style={styles.logoutFullButton} onPress={handleLogout}>
        <Text style={styles.logoutFullText}>تسجيل الخروج</Text>
      </TouchableOpacity>
    </View>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'Available': return renderAvailable();
      case 'My Jobs':   return renderMyJobs();
      case 'Profile':   return renderProfile();
    }
  };

  const renderBottomNav = () => (
    <View style={styles.bottomNav}>
      {TABS.map((tab) => (
        <TouchableOpacity
          key={tab.key}
          style={[styles.navItem, activeTab === tab.key && styles.navItemActive]}
          onPress={() => setActiveTab(tab.key)}
        >
          <Text style={styles.navIcon}>{tab.icon}</Text>
          <Text style={[styles.navLabel, activeTab === tab.key && styles.navLabelActive]}>
            {tab.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <View style={styles.container}>
      {renderHeader()}
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#22D3EE" />}
      >
        {renderContent()}
      </ScrollView>
      {renderBottomNav()}
    </View>
  );
};

const styles = StyleSheet.create({
  container:        { flex: 1, backgroundColor: '#F8FAFC' },
  scrollContent:    { paddingBottom: 110 },
  header:           { backgroundColor: '#0A4F6E', paddingHorizontal: 20, paddingTop: 56, paddingBottom: 20 },
  headerTop:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  welcome:          { fontSize: 14, color: 'rgba(255,255,255,0.75)' },
  userName:         { fontSize: 22, fontWeight: 'bold', color: '#FFFFFF', marginTop: 2 },
  userEmail:        { fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 2 },
  logoutButton:     { backgroundColor: 'rgba(255,255,255,0.18)', paddingHorizontal: 14, paddingVertical: 7, borderRadius: 8 },
  logoutText:       { color: '#FFFFFF', fontSize: 13, fontWeight: '600' },
  earningsBanner:   { marginTop: 16, backgroundColor: 'rgba(34,211,238,0.18)', borderRadius: 12, padding: 14, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  earningsLabel:    { color: 'rgba(255,255,255,0.85)', fontSize: 14 },
  earningsValue:    { color: '#22D3EE', fontSize: 20, fontWeight: 'bold' },
  statsRow:         { flexDirection: 'row', justifyContent: 'space-around', backgroundColor: '#FFFFFF', borderRadius: 16, padding: 20, marginBottom: 16, elevation: 2, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 8 },
  statCard:         { alignItems: 'center' },
  statNumber:       { fontSize: 20, fontWeight: 'bold', color: '#0A4F6E' },
  statLabel:        { color: '#6B7280', marginTop: 4, fontSize: 12 },
  section:          { paddingHorizontal: 16, paddingTop: 16 },
  sectionTitle:     { fontSize: 17, fontWeight: '700', color: '#0F172A', marginBottom: 12 },
  emptyText:        { color: '#9CA3AF', textAlign: 'center', marginVertical: 20, fontSize: 14 },
  jobCard:          { backgroundColor: '#FFFFFF', borderRadius: 16, padding: 16, marginBottom: 12, elevation: 2, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8 },
  jobHeader:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  jobClient:        { fontSize: 15, fontWeight: '700', color: '#0F172A', flex: 1 },
  statusBadge:      { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  statusText:       { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  jobDetails:       { color: '#475569', marginBottom: 6, fontSize: 13 },
  jobPayment:       { color: '#0A4F6E', fontWeight: '700', fontSize: 15, marginBottom: 10 },
  jobNotes:         { color: '#64748B', fontSize: 12, marginBottom: 10 },
  acceptButton:     { backgroundColor: '#22D3EE', paddingVertical: 12, borderRadius: 12, alignItems: 'center' },
  acceptButtonText: { color: '#0F172A', fontWeight: 'bold', fontSize: 14 },
  completeButton:   { backgroundColor: '#D1FAE5', paddingVertical: 12, borderRadius: 12, alignItems: 'center' },
  completeButtonText:{ color: '#065F46', fontWeight: 'bold', fontSize: 14 },
  ratingText:       { color: '#D97706', fontWeight: '600', marginTop: 6 },
  buttonDisabled:   { opacity: 0.55 },
  profileCard:      { backgroundColor: '#FFFFFF', borderRadius: 20, padding: 24, alignItems: 'center', marginBottom: 16, elevation: 2 },
  profileAvatar:    { fontSize: 56, marginBottom: 12 },
  profileName:      { fontSize: 20, fontWeight: 'bold', color: '#0F172A' },
  profileEmail:     { color: '#6B7280', marginTop: 4, fontSize: 14 },
  profileBadge:     { marginTop: 10, backgroundColor: '#ECFDF5', paddingHorizontal: 14, paddingVertical: 5, borderRadius: 999 },
  profileBadgeText: { color: '#065F46', fontWeight: '700', fontSize: 12 },
  logoutFullButton: { backgroundColor: '#FEE2E2', borderRadius: 14, padding: 16, alignItems: 'center', marginTop: 16 },
  logoutFullText:   { color: '#DC2626', fontWeight: '700', fontSize: 15 },
  bottomNav:        { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: '#E5E7EB', paddingVertical: 10, paddingBottom: 20 },
  navItem:          { flex: 1, alignItems: 'center', paddingVertical: 4 },
  navItemActive:    { },
  navIcon:          { fontSize: 20, marginBottom: 3 },
  navLabel:         { fontSize: 11, color: '#9CA3AF' },
  navLabelActive:   { color: '#0A4F6E', fontWeight: '700' },
});

export default ProviderDashboard;
