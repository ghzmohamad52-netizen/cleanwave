import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, RefreshControl,
} from 'react-native';
import {
  collection, onSnapshot, query, where, orderBy,
} from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';

import { db, auth } from '../config/firebase';
import { AppUser, Job, RootStackParamList } from '../types';
import { getStatusText, getStatusColor, formatMAD } from '../utils/jobHelpers';

type Props = {
  navigation: StackNavigationProp<RootStackParamList, 'ClientDashboard'>;
};

type Tab = 'Home' | 'Jobs' | 'Profile';

const TABS: { key: Tab; label: string; icon: string }[] = [
  { key: 'Home',    label: 'Home',    icon: '🏠' },
  { key: 'Jobs',    label: 'Jobs',    icon: '🗂️' },
  { key: 'Profile', label: 'Profile', icon: '👤' },
];

const ClientDashboard: React.FC<Props> = ({ navigation }) => {
  const [jobs, setJobs]           = useState<Job[]>([]);
  const [user, setUser]           = useState<AppUser | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('Home');
  const [refreshing, setRefreshing] = useState(false);

  // Load user from AsyncStorage
  useEffect(() => {
    AsyncStorage.getItem('user').then((stored) => {
      if (stored) setUser(JSON.parse(stored));
    });
  }, []);

  // Subscribe to THIS client's jobs only
  useEffect(() => {
    if (!user?.uid) return;

    const jobsRef  = collection(db, 'jobs');
    const jobQuery = query(
      jobsRef,
      where('clientId', '==', user.uid),
      orderBy('createdAt', 'desc'),
    );

    const unsubscribe = onSnapshot(jobQuery, (snapshot) => {
      const data: Job[] = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...(doc.data() as Omit<Job, 'id'>),
      }));
      setJobs(data);
    });

    return unsubscribe;
  }, [user?.uid]);

  const handleLogout = () => {
    Alert.alert('تأكيد', 'هل تريد تسجيل الخروج؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'تسجيل الخروج',
        style: 'destructive',
        onPress: async () => {
          try {
            await signOut(auth);
            await AsyncStorage.multiRemove(['token', 'user']);
            navigation.replace('Login');
          } catch {
            Alert.alert('خطأ', 'فشل في تسجيل الخروج');
          }
        },
      },
    ]);
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 800);
  }, []);

  const activeJobs    = jobs.filter((j) => j.status !== 'completed');
  const completedJobs = jobs.filter((j) => j.status === 'completed');
  const avgRating     = completedJobs.length
    ? (completedJobs.reduce((s, j) => s + (j.rating ?? 0), 0) / completedJobs.length).toFixed(1)
    : '—';

  /* ── Render helpers ─────────────────────────────────────────────────── */

  const renderHeader = () => (
    <View style={styles.header}>
      <View style={styles.headerTop}>
        <View>
          <Text style={styles.welcome}>مرحباً بك،</Text>
          <Text style={styles.userName}>{user?.firstName || 'العميل'}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
        </View>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutText}>خروج</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderStats = () => (
    <View style={styles.statsContainer}>
      {[
        { label: 'Active Jobs',  value: String(activeJobs.length) },
        { label: 'Completed',    value: String(completedJobs.length) },
        { label: 'Avg Rating',   value: avgRating },
      ].map((s) => (
        <View key={s.label} style={styles.statCard}>
          <Text style={styles.statNumber}>{s.value}</Text>
          <Text style={styles.statLabel}>{s.label}</Text>
        </View>
      ))}
    </View>
  );

  const renderJobCard = (job: Job) => (
    <View key={job.id} style={styles.jobCard}>
      <View style={styles.jobHeader}>
        <Text style={styles.jobLocation}>{job.location}</Text>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status) }]}>
          <Text style={styles.statusText}>{getStatusText(job.status)}</Text>
        </View>
      </View>
      <Text style={styles.jobDetails}>
        📐 {job.area} m²  ·  📅 {job.date}
      </Text>
      <Text style={styles.jobPayment}>{formatMAD(job.payment)}</Text>
      {job.notes ? <Text style={styles.jobNotes}>📝 {job.notes}</Text> : null}
    </View>
  );

  /* ── Tab content ────────────────────────────────────────────────────── */

  const renderHome = () => (
    <>
      {renderStats()}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Jobs</Text>
        {jobs.length === 0
          ? <Text style={styles.emptyText}>لا توجد طلبات بعد. احجز أول خدمة!</Text>
          : jobs.slice(0, 3).map(renderJobCard)
        }
      </View>
      <TouchableOpacity
        style={styles.bookButton}
        onPress={() => navigation.navigate('BookService')}
      >
        <Text style={styles.bookButtonText}>🌊  Book New Cleaning Service</Text>
      </TouchableOpacity>
    </>
  );

  const renderJobs = () => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>Active Jobs ({activeJobs.length})</Text>
      {activeJobs.length === 0
        ? <Text style={styles.emptyText}>لا توجد طلبات نشطة</Text>
        : activeJobs.map(renderJobCard)
      }
      <Text style={[styles.sectionTitle, { marginTop: 20 }]}>
        Completed ({completedJobs.length})
      </Text>
      {completedJobs.length === 0
        ? <Text style={styles.emptyText}>لا توجد طلبات مكتملة</Text>
        : completedJobs.map(renderJobCard)
      }
    </View>
  );

  const renderProfile = () => (
    <View style={styles.section}>
      <View style={styles.profileCard}>
        <Text style={styles.profileAvatar}>👤</Text>
        <Text style={styles.profileName}>{user?.firstName}</Text>
        <Text style={styles.profileEmail}>{user?.email}</Text>
        <View style={styles.profileBadge}>
          <Text style={styles.profileBadgeText}>Client</Text>
        </View>
      </View>
      <View style={styles.profileStats}>
        <View style={styles.profileStatItem}>
          <Text style={styles.profileStatNum}>{jobs.length}</Text>
          <Text style={styles.profileStatLabel}>Total Jobs</Text>
        </View>
        <View style={styles.profileStatItem}>
          <Text style={styles.profileStatNum}>{completedJobs.length}</Text>
          <Text style={styles.profileStatLabel}>Completed</Text>
        </View>
        <View style={styles.profileStatItem}>
          <Text style={styles.profileStatNum}>{avgRating}</Text>
          <Text style={styles.profileStatLabel}>Avg Rating</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.logoutFullButton} onPress={handleLogout}>
        <Text style={styles.logoutFullText}>تسجيل الخروج</Text>
      </TouchableOpacity>
    </View>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'Home':    return renderHome();
      case 'Jobs':    return renderJobs();
      case 'Profile': return renderProfile();
    }
  };

  const renderBottomNav = () => (
    <View style={styles.bottomNav}>
      {TABS.map((tab) => (
        <TouchableOpacity
          key={tab.key}
          style={[styles.navItem, activeTab === tab.key && styles.navItemActive]}
          onPress={() => setActiveTab(tab.key)}
        >
          <Text style={styles.navIcon}>{tab.icon}</Text>
          <Text style={[styles.navLabel, activeTab === tab.key && styles.navLabelActive]}>
            {tab.label}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  return (
    <View style={styles.container}>
      {renderHeader()}
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#22D3EE" />}
      >
        {renderContent()}
      </ScrollView>
      {renderBottomNav()}
    </View>
  );
};

const styles = StyleSheet.create({
  container:         { flex: 1, backgroundColor: '#F8FAFC' },
  scrollContent:     { paddingBottom: 110 },
  header:            { backgroundColor: '#0A4F6E', paddingHorizontal: 20, paddingTop: 56, paddingBottom: 20 },
  headerTop:         { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  welcome:           { fontSize: 14, color: 'rgba(255,255,255,0.75)' },
  userName:          { fontSize: 22, fontWeight: 'bold', color: '#FFFFFF', marginTop: 2 },
  userEmail:         { fontSize: 13, color: 'rgba(255,255,255,0.7)', marginTop: 2 },
  logoutButton:      { backgroundColor: 'rgba(255,255,255,0.18)', paddingHorizontal: 14, paddingVertical: 7, borderRadius: 8 },
  logoutText:        { color: '#FFFFFF', fontSize: 13, fontWeight: '600' },
  statsContainer:    { flexDirection: 'row', justifyContent: 'space-around', backgroundColor: '#FFFFFF', margin: 16, borderRadius: 16, padding: 20, elevation: 3, shadowColor: '#000', shadowOpacity: 0.08, shadowRadius: 10 },
  statCard:          { alignItems: 'center' },
  statNumber:        { fontSize: 22, fontWeight: 'bold', color: '#0A4F6E' },
  statLabel:         { color: '#6B7280', marginTop: 4, fontSize: 12 },
  section:           { paddingHorizontal: 16, marginTop: 4 },
  sectionTitle:      { fontSize: 17, fontWeight: '700', color: '#0F172A', marginBottom: 12 },
  emptyText:         { color: '#9CA3AF', textAlign: 'center', marginVertical: 20, fontSize: 14 },
  jobCard:           { backgroundColor: '#FFFFFF', borderRadius: 16, padding: 16, marginBottom: 12, elevation: 2, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 8 },
  jobHeader:         { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  jobLocation:       { fontSize: 15, fontWeight: '700', color: '#0F172A', flex: 1 },
  statusBadge:       { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  statusText:        { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  jobDetails:        { color: '#475569', marginBottom: 6, fontSize: 13 },
  jobPayment:        { color: '#0A4F6E', fontWeight: '700', fontSize: 15 },
  jobNotes:          { color: '#64748B', fontSize: 12, marginTop: 4 },
  bookButton:        { backgroundColor: '#22D3EE', marginHorizontal: 16, marginTop: 16, paddingVertical: 16, borderRadius: 16, alignItems: 'center' },
  bookButtonText:    { color: '#0F172A', fontWeight: 'bold', fontSize: 15 },
  profileCard:       { backgroundColor: '#FFFFFF', borderRadius: 20, padding: 24, alignItems: 'center', marginBottom: 16, elevation: 2, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 10 },
  profileAvatar:     { fontSize: 56, marginBottom: 12 },
  profileName:       { fontSize: 20, fontWeight: 'bold', color: '#0F172A' },
  profileEmail:      { color: '#6B7280', marginTop: 4, fontSize: 14 },
  profileBadge:      { marginTop: 10, backgroundColor: '#E0F2FE', paddingHorizontal: 14, paddingVertical: 5, borderRadius: 999 },
  profileBadgeText:  { color: '#0A4F6E', fontWeight: '700', fontSize: 12 },
  profileStats:      { flexDirection: 'row', backgroundColor: '#FFFFFF', borderRadius: 16, padding: 20, marginBottom: 16, justifyContent: 'space-around', elevation: 2 },
  profileStatItem:   { alignItems: 'center' },
  profileStatNum:    { fontSize: 20, fontWeight: 'bold', color: '#0A4F6E' },
  profileStatLabel:  { color: '#6B7280', fontSize: 12, marginTop: 3 },
  logoutFullButton:  { backgroundColor: '#FEE2E2', borderRadius: 14, padding: 16, alignItems: 'center' },
  logoutFullText:    { color: '#DC2626', fontWeight: '700', fontSize: 15 },
  bottomNav:         { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: '#E5E7EB', paddingVertical: 10, paddingBottom: 20 },
  navItem:           { flex: 1, alignItems: 'center', paddingVertical: 4 },
  navItemActive:     { },
  navIcon:           { fontSize: 20, marginBottom: 3 },
  navLabel:          { fontSize: 11, color: '#9CA3AF' },
  navLabelActive:    { color: '#0A4F6E', fontWeight: '700' },
});

export default ClientDashboard;
