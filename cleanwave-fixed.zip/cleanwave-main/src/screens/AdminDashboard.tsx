import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert,
} from 'react-native';
import {
  collection, onSnapshot, query, orderBy,
  doc, updateDoc,
} from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';

import { db, auth } from '../config/firebase';
import { AppUser, Job, RootStackParamList } from '../types';
import { getStatusText, getStatusColor, formatMAD } from '../utils/jobHelpers';

type Props = {
  navigation: StackNavigationProp<RootStackParamList, 'AdminDashboard'>;
};

type Tab = 'Overview' | 'All Jobs' | 'Profile';

const TABS: { key: Tab; label: string; icon: string }[] = [
  { key: 'Overview',  label: 'Overview',  icon: '📊' },
  { key: 'All Jobs',  label: 'All Jobs',  icon: '🗂️' },
  { key: 'Profile',   label: 'Profile',   icon: '👤' },
];

const AdminDashboard: React.FC<Props> = ({ navigation }) => {
  const [jobs, setJobs]           = useState<Job[]>([]);
  const [user, setUser]           = useState<AppUser | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('Overview');

  useEffect(() => {
    AsyncStorage.getItem('user').then((s) => { if (s) setUser(JSON.parse(s)); });
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'jobs'), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snap) => {
      setJobs(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Job, 'id'>) })));
    });
  }, []);

  const handleLogout = () => {
    Alert.alert('تأكيد', 'هل تريد تسجيل الخروج؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'تسجيل الخروج', style: 'destructive',
        onPress: async () => {
          await signOut(auth);
          await AsyncStorage.multiRemove(['token', 'user']);
          navigation.replace('Login');
        },
      },
    ]);
  };

  const handleDeleteJob = (jobId: string) => {
    Alert.alert('إلغاء الطلب', 'هل تريد تغيير حالة الطلب إلى "معلق"؟', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'تأكيد',
        onPress: async () => {
          try {
            await updateDoc(doc(db, 'jobs', jobId), { status: 'pending' });
          } catch {
            Alert.alert('خطأ', 'فشل في تحديث الطلب');
          }
        },
      },
    ]);
  };

  const total     = jobs.length;
  const available = jobs.filter((j) => j.status === 'available').length;
  const active    = jobs.filter((j) => ['accepted', 'in_progress'].includes(j.status)).length;
  const completed = jobs.filter((j) => j.status === 'completed').length;
  const revenue   = jobs.filter((j) => j.status === 'completed').reduce((s, j) => s + (j.payment ?? 0), 0);

  const renderHeader = () => (
    <View style={styles.header}>
      <View style={styles.headerTop}>
        <View>
          <Text style={styles.welcome}>لوحة التحكم</Text>
          <Text style={styles.userName}>{user?.firstName || 'المدير'}</Text>
        </View>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutText}>خروج</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderOverview = () => (
    <View style={styles.section}>
      <View style={styles.statsGrid}>
        {[
          { label: 'Total Jobs',   value: total,            color: '#0A4F6E' },
          { label: 'Available',    value: available,        color: '#10B981' },
          { label: 'In Progress',  value: active,           color: '#22D3EE' },
          { label: 'Completed',    value: completed,        color: '#6B7280' },
        ].map((s) => (
          <View key={s.label} style={styles.statCard}>
            <Text style={[styles.statNumber, { color: s.color }]}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>
      <View style={styles.revenueCard}>
        <Text style={styles.revenueLabel}>إجمالي الإيرادات</Text>
        <Text style={styles.revenueValue}>{formatMAD(revenue)}</Text>
      </View>
      <Text style={styles.sectionTitle}>Recent Activity</Text>
      {jobs.slice(0, 5).map((job) => (
        <View key={job.id} style={styles.activityRow}>
          <View style={[styles.statusDot, { backgroundColor: getStatusColor(job.status) }]} />
          <Text style={styles.activityText} numberOfLines={1}>
            {job.location} — {job.clientName}
          </Text>
          <Text style={styles.activityStatus}>{getStatusText(job.status)}</Text>
        </View>
      ))}
    </View>
  );

  const renderAllJobs = () => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>All Jobs ({total})</Text>
      {jobs.map((job) => (
        <View key={job.id} style={styles.jobCard}>
          <View style={styles.jobHeader}>
            <Text style={styles.jobLocation}>{job.location}</Text>
            <View style={[styles.statusBadge, { backgroundColor: getStatusColor(job.status) }]}>
              <Text style={styles.statusText}>{getStatusText(job.status)}</Text>
            </View>
          </View>
          <Text style={styles.jobMeta}>
            👤 {job.clientName}  ·  📐 {job.area} m²  ·  📅 {job.date}
          </Text>
          <Text style={styles.jobPayment}>{formatMAD(job.payment)}</Text>
          {job.status !== 'completed' && (
            <TouchableOpacity
              style={styles.adminAction}
              onPress={() => handleDeleteJob(job.id)}
            >
              <Text style={styles.adminActionText}>Set to Pending</Text>
            </TouchableOpacity>
          )}
        </View>
      ))}
    </View>
  );

  const renderProfile = () => (
    <View style={styles.section}>
      <View style={styles.profileCard}>
        <Text style={styles.profileAvatar}>⚙️</Text>
        <Text style={styles.profileName}>{user?.firstName}</Text>
        <Text style={styles.profileEmail}>{user?.email}</Text>
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>Admin</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.logoutFullButton} onPress={handleLogout}>
        <Text style={styles.logoutFullText}>تسجيل الخروج</Text>
      </TouchableOpacity>
    </View>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'Overview':  return renderOverview();
      case 'All Jobs':  return renderAllJobs();
      case 'Profile':   return renderProfile();
    }
  };

  return (
    <View style={styles.container}>
      {renderHeader()}
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {renderContent()}
      </ScrollView>
      <View style={styles.bottomNav}>
        {TABS.map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={[styles.navItem, activeTab === tab.key && styles.navItemActive]}
            onPress={() => setActiveTab(tab.key)}
          >
            <Text style={styles.navIcon}>{tab.icon}</Text>
            <Text style={[styles.navLabel, activeTab === tab.key && styles.navLabelActive]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container:       { flex: 1, backgroundColor: '#F8FAFC' },
  scrollContent:   { paddingBottom: 110 },
  header:          { backgroundColor: '#0A4F6E', paddingHorizontal: 20, paddingTop: 56, paddingBottom: 20 },
  headerTop:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  welcome:         { fontSize: 14, color: 'rgba(255,255,255,0.75)' },
  userName:        { fontSize: 22, fontWeight: 'bold', color: '#FFFFFF', marginTop: 2 },
  logoutButton:    { backgroundColor: 'rgba(255,255,255,0.18)', paddingHorizontal: 14, paddingVertical: 7, borderRadius: 8 },
  logoutText:      { color: '#FFFFFF', fontSize: 13, fontWeight: '600' },
  section:         { paddingHorizontal: 16, paddingTop: 16 },
  statsGrid:       { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 16 },
  statCard:        { backgroundColor: '#FFFFFF', borderRadius: 14, padding: 16, width: '48%', marginBottom: 12, alignItems: 'center', elevation: 2 },
  statNumber:      { fontSize: 28, fontWeight: 'bold' },
  statLabel:       { color: '#6B7280', marginTop: 4, fontSize: 12 },
  revenueCard:     { backgroundColor: '#0A4F6E', borderRadius: 16, padding: 20, marginBottom: 20, alignItems: 'center' },
  revenueLabel:    { color: 'rgba(255,255,255,0.75)', fontSize: 14, marginBottom: 4 },
  revenueValue:    { color: '#22D3EE', fontSize: 30, fontWeight: 'bold' },
  sectionTitle:    { fontSize: 17, fontWeight: '700', color: '#0F172A', marginBottom: 12 },
  activityRow:     { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#F1F5F9' },
  statusDot:       { width: 8, height: 8, borderRadius: 4, marginRight: 10 },
  activityText:    { flex: 1, color: '#374151', fontSize: 14 },
  activityStatus:  { color: '#9CA3AF', fontSize: 12 },
  jobCard:         { backgroundColor: '#FFFFFF', borderRadius: 16, padding: 16, marginBottom: 12, elevation: 2 },
  jobHeader:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  jobLocation:     { fontSize: 15, fontWeight: '700', color: '#0F172A', flex: 1 },
  statusBadge:     { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999 },
  statusText:      { color: '#FFFFFF', fontSize: 11, fontWeight: '700' },
  jobMeta:         { color: '#475569', fontSize: 13, marginBottom: 6 },
  jobPayment:      { color: '#0A4F6E', fontWeight: '700', fontSize: 15, marginBottom: 10 },
  adminAction:     { backgroundColor: '#FEF3C7', borderRadius: 10, padding: 10, alignItems: 'center' },
  adminActionText: { color: '#92400E', fontWeight: '600', fontSize: 13 },
  profileCard:     { backgroundColor: '#FFFFFF', borderRadius: 20, padding: 24, alignItems: 'center', marginBottom: 16, elevation: 2 },
  profileAvatar:   { fontSize: 56, marginBottom: 12 },
  profileName:     { fontSize: 20, fontWeight: 'bold', color: '#0F172A' },
  profileEmail:    { color: '#6B7280', marginTop: 4, fontSize: 14 },
  adminBadge:      { marginTop: 10, backgroundColor: '#F3E8FF', paddingHorizontal: 14, paddingVertical: 5, borderRadius: 999 },
  adminBadgeText:  { color: '#6D28D9', fontWeight: '700', fontSize: 12 },
  logoutFullButton:{ backgroundColor: '#FEE2E2', borderRadius: 14, padding: 16, alignItems: 'center', marginTop: 8 },
  logoutFullText:  { color: '#DC2626', fontWeight: '700', fontSize: 15 },
  bottomNav:       { position: 'absolute', left: 0, right: 0, bottom: 0, flexDirection: 'row', backgroundColor: '#FFFFFF', borderTopWidth: 1, borderTopColor: '#E5E7EB', paddingVertical: 10, paddingBottom: 20 },
  navItem:         { flex: 1, alignItems: 'center', paddingVertical: 4 },
  navItemActive:   { },
  navIcon:         { fontSize: 20, marginBottom: 3 },
  navLabel:        { fontSize: 11, color: '#9CA3AF' },
  navLabelActive:  { color: '#0A4F6E', fontWeight: '700' },
});

export default AdminDashboard;
