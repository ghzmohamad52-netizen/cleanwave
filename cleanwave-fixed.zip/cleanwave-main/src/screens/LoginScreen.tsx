import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Alert, ScrollView, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as WebBrowser from 'expo-web-browser';
import * as GoogleAuthSession from 'expo-auth-session/providers/google';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithCredential,
} from 'firebase/auth';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackNavigationProp } from '@react-navigation/stack';
import Constants from 'expo-constants';

import { auth } from '../config/firebase';
import { AppUser, UserRole, RootStackParamList } from '../types';

type Props = {
  navigation: StackNavigationProp<RootStackParamList, 'Login'>;
};

WebBrowser.maybeCompleteAuthSession();

const extra = (Constants.expoConfig?.extra ?? {}) as Record<string, string>;

const ROLE_OPTIONS: { key: UserRole; label: string; description: string }[] = [
  { key: 'client',   label: 'عميل 🏨',       description: 'حجز خدمات التنظيف' },
  { key: 'provider', label: 'مقدم خدمة 🧹',  description: 'تقديم خدمات التنظيف' },
  { key: 'admin',    label: 'مدير ⚙️',        description: 'إدارة المنصة' },
];

const getErrorMessage = (code: string): string => {
  switch (code) {
    case 'auth/wrong-password':       return 'كلمة المرور غير صحيحة';
    case 'auth/user-not-found':       return 'المستخدم غير موجود';
    case 'auth/email-already-in-use': return 'البريد الإلكتروني مستخدم بالفعل';
    case 'auth/weak-password':        return 'كلمة المرور ضعيفة جداً (6 أحرف على الأقل)';
    case 'auth/invalid-email':        return 'البريد الإلكتروني غير صحيح';
    case 'auth/invalid-credential':   return 'بيانات الدخول غير صحيحة';
    default:                          return 'حدث خطأ في المصادقة';
  }
};

const saveUserData = async (user: AppUser): Promise<void> => {
  await AsyncStorage.setItem('user', JSON.stringify(user));
  await AsyncStorage.setItem('token', user.uid);
};

const routeByRole = (
  role: UserRole,
  navigation: StackNavigationProp<RootStackParamList, 'Login'>,
) => {
  if (role === 'provider') navigation.replace('ProviderDashboard');
  else if (role === 'admin') navigation.replace('AdminDashboard');
  else navigation.replace('ClientDashboard');
};

const LoginScreen: React.FC<Props> = ({ navigation }) => {
  const [email, setEmail]             = useState('');
  const [password, setPassword]       = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('client');
  const [isLogin, setIsLogin]         = useState(true);
  const [loading, setLoading]         = useState(false);

  const [request, response, promptAsync] = GoogleAuthSession.useIdTokenAuthRequest({
    clientId:        extra.googleWebClientId,
    androidClientId: extra.googleAndroidClientId,
    iosClientId:     extra.googleIosClientId,
    scopes: ['profile', 'email'],
  });

  useEffect(() => {
    if (response?.type === 'success' && response.params.id_token) {
      handleGoogleAuth(response.params.id_token);
    }
  }, [response]);

  const handleEmailLogin = async () => {
    if (!email.trim() || !password) {
      Alert.alert('خطأ', 'يرجى ملء جميع الحقول');
      return;
    }

    setLoading(true);
    try {
      const credential = isLogin
        ? await signInWithEmailAndPassword(auth, email.trim(), password)
        : await createUserWithEmailAndPassword(auth, email.trim(), password);

      const fbUser = credential.user;
      const userData: AppUser = {
        uid:       fbUser.uid,
        email:     fbUser.email,
        role:      selectedRole,
        firstName: fbUser.displayName || email.split('@')[0],
      };

      await saveUserData(userData);
      routeByRole(selectedRole, navigation);
    } catch (err: any) {
      Alert.alert('خطأ في المصادقة', getErrorMessage(err?.code ?? ''));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async (idToken: string) => {
    setLoading(true);
    try {
      const cred       = GoogleAuthProvider.credential(idToken);
      const result     = await signInWithCredential(auth, cred);
      const fbUser     = result.user;
      const userData: AppUser = {
        uid:       fbUser.uid,
        email:     fbUser.email,
        role:      selectedRole,
        firstName: fbUser.displayName || fbUser.email?.split('@')[0] || 'مستخدم',
      };

      await saveUserData(userData);
      routeByRole(selectedRole, navigation);
    } catch (err: any) {
      Alert.alert('خطأ في جوجل', getErrorMessage(err?.code ?? ''));
    } finally {
      setLoading(false);
    }
  };

  return (
    <LinearGradient colors={['#0A4F6E', '#22D3EE']} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContainer} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <Text style={styles.logo}>🌊</Text>
          <Text style={styles.title}>مرحباً بك في Cleanwave</Text>
          <Text style={styles.subtitle}>تنظيف الشواطئ أصبح سهلاً</Text>
        </View>

        <View style={styles.form}>
          {/* Role selector */}
          <Text style={styles.sectionTitle}>اختر دورك</Text>
          <View style={styles.roleSelector}>
            {ROLE_OPTIONS.map((role) => (
              <TouchableOpacity
                key={role.key}
                style={[styles.roleButton, selectedRole === role.key && styles.roleButtonSelected]}
                onPress={() => setSelectedRole(role.key)}
                accessibilityLabel={role.label}
              >
                <Text style={[styles.roleButtonText, selectedRole === role.key && styles.roleButtonTextSelected]}>
                  {role.label}
                </Text>
                <Text style={[styles.roleDescription, selectedRole === role.key && styles.roleDescriptionSelected]}>
                  {role.description}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Auth form */}
          <Text style={styles.sectionTitle}>
            {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'}
          </Text>

          <TextInput
            style={styles.input}
            placeholder="البريد الإلكتروني"
            placeholderTextColor="#B0C4D0"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
          />

          <TextInput
            style={styles.input}
            placeholder="كلمة المرور"
            placeholderTextColor="#B0C4D0"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity
            style={[styles.primaryButton, loading && styles.buttonDisabled]}
            onPress={handleEmailLogin}
            disabled={loading}
          >
            {loading
              ? <ActivityIndicator color="#0F172A" />
              : <Text style={styles.primaryButtonText}>{isLogin ? 'تسجيل الدخول' : 'إنشاء حساب'}</Text>
            }
          </TouchableOpacity>

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>أو</Text>
            <View style={styles.dividerLine} />
          </View>

          <TouchableOpacity
            style={[styles.googleButton, (loading || !request) && styles.buttonDisabled]}
            onPress={() => promptAsync()}
            disabled={loading || !request}
          >
            <Text style={styles.googleButtonText}>🔵  المتابعة بجوجل</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.switchMode} onPress={() => setIsLogin(!isLogin)}>
            <Text style={styles.switchModeText}>
              {isLogin ? 'ليس لديك حساب؟ إنشاء حساب' : 'لديك حساب بالفعل؟ تسجيل الدخول'}
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container:              { flex: 1 },
  scrollContainer:        { flexGrow: 1, padding: 24, paddingTop: 60 },
  header:                 { alignItems: 'center', marginBottom: 28 },
  logo:                   { fontSize: 52, marginBottom: 12 },
  title:                  { fontSize: 28, fontWeight: 'bold', color: '#FFFFFF', marginBottom: 6, textAlign: 'center' },
  subtitle:               { fontSize: 15, color: '#E0F2FE', textAlign: 'center' },
  form:                   { backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: 24, padding: 20 },
  sectionTitle:           { color: '#FFFFFF', fontSize: 16, fontWeight: '700', marginBottom: 12 },
  roleSelector:           { marginBottom: 20 },
  roleButton:             { padding: 14, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.10)', borderColor: 'rgba(255,255,255,0.18)', borderWidth: 1, marginBottom: 10 },
  roleButtonSelected:     { backgroundColor: 'rgba(255,255,255,0.25)', borderColor: '#22D3EE' },
  roleButtonText:         { color: '#FFFFFF', fontWeight: '700', fontSize: 15, marginBottom: 2 },
  roleButtonTextSelected: { color: '#F8FAFC' },
  roleDescription:        { color: '#B0C4D0', fontSize: 13 },
  roleDescriptionSelected:{ color: '#E0F2FE' },
  input:                  { backgroundColor: 'rgba(255,255,255,0.14)', color: '#FFFFFF', borderRadius: 14, padding: 14, marginBottom: 12, borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', fontSize: 15 },
  primaryButton:          { backgroundColor: '#22D3EE', padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 12 },
  primaryButtonText:      { color: '#0F172A', fontWeight: 'bold', fontSize: 16 },
  googleButton:           { backgroundColor: '#FFFFFF', padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 12 },
  googleButtonText:       { color: '#0F172A', fontWeight: 'bold', fontSize: 15 },
  switchMode:             { alignSelf: 'center', marginTop: 4, padding: 6 },
  switchModeText:         { color: '#E0F2FE', textDecorationLine: 'underline', fontSize: 14 },
  divider:                { flexDirection: 'row', alignItems: 'center', marginVertical: 10 },
  dividerLine:            { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.25)' },
  dividerText:            { color: '#E0F2FE', marginHorizontal: 10 },
  buttonDisabled:         { opacity: 0.55 },
});

export default LoginScreen;
